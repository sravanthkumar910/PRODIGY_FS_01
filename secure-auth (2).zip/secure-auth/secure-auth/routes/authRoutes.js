const express = require('express');
const router = express.Router();
const { register, login } = require('../controllers/authController');
const { auth, roleCheck } = require('../middleware/authMiddleware');

router.post('/register', register);
router.post('/login', login);

router.get('/protected', auth, (req, res) => {
  res.json({ msg: 'Access granted to protected route', user: req.user });
});

router.get('/admin', auth, roleCheck(['admin']), (req, res) => {
  res.json({ msg: 'Admin access granted' });
});

module.exports = router;
