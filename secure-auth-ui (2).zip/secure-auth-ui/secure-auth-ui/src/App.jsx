import { useState } from 'react';

export default function App() {
  const [activeTab, setActiveTab] = useState('login');
  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [registerData, setRegisterData] = useState({ name: '', email: '', password: '' });

  const handleTabClick = (tab) => setActiveTab(tab);

  // Helper to block '@' in email inputs
  //const blockAtChar = (value) => value.replace(/@/g, '');

  const handleLoginChange = (e) => {
    const { name, value } = e.target;
    if (name === 'email') {
      setLoginData({ ...loginData, email: (value) });
    } else {
      setLoginData({ ...loginData, [name]: value });
    }
  };

  const handleRegisterChange = (e) => {
    const { name, value } = e.target;
    if (name === 'email') {
      setRegisterData({ ...registerData, email: (value) });
    } else {
      setRegisterData({ ...registerData, [name]: value });
    }
  };

  const handleLoginSubmit = (e) => {
    e.preventDefault();
    alert(`Logging in with email: ${loginData.email}`);
  };

  const handleRegisterSubmit = (e) => {
    e.preventDefault();
    alert(`Registering user: ${registerData.name}, email: ${registerData.email}`);
  };

  return (
    <>
      <style>{`
        .app-container {
          height: 100vh;
          display: flex;
          justify-content: center;
          align-items: center;
          font-family: Arial, sans-serif;

          background-image: 
            linear-gradient(rgba(43, 88, 118, 0.6), rgba(78, 67, 118, 0.6)),
            url('https://images.unsplash.com/photo-1556761175-4b46a572b786?auto=format&fit=crop&w=1470&q=90');
          background-size: cover;
          background-position: center center;
          background-repeat: no-repeat;

          image-rendering: optimizeQuality;
          -webkit-font-smoothing: antialiased;
          -moz-osx-font-smoothing: grayscale;
        }
        .auth-box {
          background-color: #fff;
          padding: 2rem;
          border-radius: 1rem;
          box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
          width: 300px;
          text-align: center;
        }
        .auth-box h2 {
          margin-bottom: 1rem;
        }
        .tab-buttons {
          display: flex;
          justify-content: space-around;
          margin-bottom: 1rem;
        }
        .tab-buttons button {
          background: #ddd;
          border: none;
          padding: 0.5rem 1rem;
          cursor: pointer;
          border-radius: 5px;
          font-weight: bold;
        }
        .tab-buttons button.active {
          background: #4e4376;
          color: #fff;
        }
        form input {
          width: 100%;
          padding: 0.5rem;
          margin: 0.5rem 0;
          border-radius: 5px;
          border: 1px solid #ccc;
        }
        form button {
          background: #4e4376;
          color: #fff;
          padding: 0.5rem;
          width: 100%;
          border: none;
          border-radius: 5px;
          cursor: pointer;
        }
      `}</style>

      <div className="app-container">
        <div className="auth-box">
          <h2>{activeTab === 'login' ? 'Login' : 'Register'}</h2>

          <div className="tab-buttons">
            <button
              className={activeTab === 'login' ? 'active' : ''}
              onClick={() => handleTabClick('login')}
            >
              Login
            </button>
            <button
              className={activeTab === 'register' ? 'active' : ''}
              onClick={() => handleTabClick('register')}
            >
              Register
            </button>
          </div>

          {activeTab === 'login' && (
            <form onSubmit={handleLoginSubmit}>
              <input
                type="text"
                name="email"
                placeholder="Email"
                value={loginData.email}
                onChange={handleLoginChange}
                required
              />
              <input
                type="password"
                name="password"
                placeholder="Password"
                value={loginData.password}
                onChange={handleLoginChange}
                required
              />
              <button type="submit">Login</button>
            </form>
          )}

          {activeTab === 'register' && (
            <form onSubmit={handleRegisterSubmit}>
              <input
                type="text"
                name="name"
                placeholder="Name"
                value={registerData.name}
                onChange={handleRegisterChange}
                required
              />
              <input
                type="email"
                name="email"
                placeholder="Email"
                value={registerData.email}
                onChange={handleRegisterChange}
                required
              />
              <input
                type="password"
                name="password"
                placeholder="Password"
                value={registerData.password}
                onChange={handleRegisterChange}
                required
              />
              <button type="submit">Register</button>
            </form>
          )}
        </div>
      </div>
    </>
  );
}
