import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function ProtectedPage() {
  const [data, setData] = useState('');

  useEffect(() => {
    const fetchProtectedData = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get(`${import.meta.env.VITE_API_URL}/protected`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setData(res.data.msg);
      } catch {
        setData('Access Denied');
      }
    };
    fetchProtectedData();
  }, []);

  return (
    <div>
      <h2>Protected Page</h2>
      <p>{data}</p>
    </div>
  );
}
